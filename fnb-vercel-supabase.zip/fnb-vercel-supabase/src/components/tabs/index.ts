export { default as IngredientsTab } from './IngredientsTab';
export { default as RecipesTab } from './RecipesTab';
export { default as EventsTab } from './EventsTab';
export { default as ReportsTab } from './ReportsTab';
export { default as SettingsTab } from './SettingsTab';
